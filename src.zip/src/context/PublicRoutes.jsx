import React, { useContext } from 'react'
import { AuthUserContext } from './AuthContextApi'

const PublicRoutes = ({children}) => {
  let {authUser}=useContext(AuthUserContext);

  if(authUser!== null){
    return <Navigate to={"/"} replace={true} />
  }else{
    return <>{children}</>
  }
}

export default PublicRoutes
