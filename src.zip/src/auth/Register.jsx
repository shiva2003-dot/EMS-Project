import { createUserWithEmailAndPassword, sendEmailVerification, updateProfile } from 'firebase/auth';
import React, { useState } from 'react'
import toast from 'react-hot-toast';
import { IoMdEyeOff } from 'react-icons/io';
import { IoEye, IoEyeOff } from 'react-icons/io5';
import { NavLink, useNavigate } from 'react-router-dom';
import Spinner from '../helper/Spinner';
import { __AUTH } from '../Backend/firebaseConfig';

const Register = () => {
  const [userData, setUserData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  let [showPassword1, setShowPassword1] = useState(true);
  let [showPassword2, setShowPassword2] = useState(true);
  let [isLoading, setIsLoading] = useState(false);

  let { username, password, confirmPassword } = userData;

  let togglePassword1 = () => {
    setShowPassword1(!showPassword1);
  };
  let togglePassword2 = () => {
    setShowPassword2(!showPassword2);
  };

  let navigate = useNavigate();


  let handleInputChange = (e) => {
    let value = e.target.value;
    let name = e.target.name;
    setUserData({ ...userData, [name]: value })
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      if (password === confirmPassword) {
        let registeredUser = await createUserWithEmailAndPassword(__AUTH, username, password);
        console.log(registeredUser);


        //! send email verification.
        sendEmailVerification(registeredUser.user);

        //! update photo URL and display name
        updateProfile(registeredUser.user, {
          displayName:"Shivakant",
          photoURL:"https://up.yimg.com/ib/th?id=OIP.Zvs5IHgOO5kip7A32UwZJgHaHa&pid=Api&rs=1&c=1&qlt=95&w=105&h=105"

        })
        toast.success(`Email verification send to your registered ${username}`);
       toast.success("user has been registered successfully")
        navigate("/auth/login")
      } else {
        toast.error("please varify the password")
      }

    } catch (error) {
      toast.error(error.message);
      console.log("Error while Register:", error)
    }
    setIsLoading(false);

  };

  return (
    <section className="flex items-center justify-center min-h-screen bg-white">
      <article className="w-full max-w-md bg-[#b8f5b3] p-8 rounded-2xl shadow-md">
        <header className='py-2'>
          <h1 className="text-2xl font-semibold text-center text-gray-700 mb-6">
            Register
          </h1>
        </header>
        <main className='w-full p-3'>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="w-full flex flex-col gap-2 mb-2">
              <label htmlFor="username" className="text-lg">
                Username
              </label>
              <input
                type="email"
                name="username"
                id="username"
                placeholder="Enter your username.."
                className="outline-none py-2 border border-black px-2 text-lg rounded-md hover:ring-1 hover:ring-blue-600"
                value={username}
                onChange={handleInputChange}
              />
            </div>

            <div className="w-full flex flex-col gap-2 mb-2 relative">
              <label htmlFor="password" className="text-lg">
                Password
              </label>
              <input
                type={showPassword1 ? "password" : "text"}
                name="password"
                id="password"
                placeholder="Enter your password.."
                className="outline-none py-2 border border-black px-2 text-lg rounded-md hover:ring-1 hover:ring-blue-600"
                value={password}
                onChange={handleInputChange}
              />
              <span
                onClick={togglePassword1}
                className="absolute right-[10px] top-[50px] text-lg cursor-pointer"
              >
                {showPassword1 ? <IoEyeOff /> : <IoEye />}
              </span>
            </div>
            <div className="w-full flex flex-col gap-2 mb-2 relative">
              <label htmlFor="password" className="text-lg">
                Confirm Password
              </label>
              <input
                type={showPassword2 ? "password" : "text"}
                name="confirmPassword"
                id="confirmPassword"
                placeholder="Confirm your password.."
                className="outline-none py-2 border border-black px-2 text-lg rounded-md hover:ring-1 hover:ring-blue-600"
                value={confirmPassword}
                onChange={handleInputChange}
              />
              <span
                onClick={togglePassword2}
                className="absolute right-[10px] top-[50px] text-lg cursor-pointer"
              >
                {showPassword2 ? <IoEyeOff /> : <IoEye />}
              </span>
            </div>

            <div className="w-full flex justify-center items-center mb-2 mt-3 p-2">
              <NavLink to={"/auth/login"} className={"hover:underline"}>
                Already have an account?
              </NavLink>
            </div>
            <div className="w-full flex justify-center items-center">

              <button
                type="submit"
                className="w-full bg-blue-400 border-black text-white py-2 rounded-lg hover:bg-green-600 transition cursor-pointer"
              >
                Sign Up
              </button>
            </div>
          </form>
        </main>
      </article>
      {isLoading && (<section className='w-[100%] h-[100vh] bg-black/50 fixed top-0'>
        <Spinner />
      </section>)}
    </section>
  );
};

export default Register;