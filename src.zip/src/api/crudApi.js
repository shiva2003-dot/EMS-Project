import axios from 'axios'
export let getUsers=()=>{
    return axios.get('http://localhost:3001/users')
}

//!C/- craete  the new user or add the  user
export let createUser=(Data)=>{
    return axios.post('http://localhost:3001/users',Data);
}

//! D-Delete the user
export let deleteUser=(id)=>{
    return axios.delete(`http://localhost:3001/users/${id}`);
}


//! U-Update the user
export let updateUser=(id,Data)=>{
    return axios.put(`http://localhost:3001/users/${id}`,Data);
}