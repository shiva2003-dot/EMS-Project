import React, { useContext } from 'react';
import { NavLink } from 'react-router-dom';
import { AuthUserContext } from '../context/AuthContextApi';

const Menu = () => {
  // Use the context
  const { authUser, logout } = useContext(AuthUserContext);

  // Authenticated User --> Add User, Profile, LogOut
  const AuthenticatedUser = () => (
    <>
      <li>
        <NavLink
          to="/add-user"
          className={({ isActive }) =>
            `${isActive ? "bg-blue-600" : ""} px-4 py-2 rounded-md text-lg cursor-pointer font-semibold hover:bg-blue-700`
          }
        >
          Add User
        </NavLink>
      </li>
      <li>
        <NavLink
          to="/profile"
          className={({ isActive }) =>
            `${isActive ? "bg-blue-600" : ""} px-4 py-2 rounded-md text-lg cursor-pointer font-semibold hover:bg-blue-700 flex items-center gap-2`
          }
        >
          <span>{authUser?.displayName || "Profile"}</span>
          <span>
            <img
              src={authUser?.photoURL || "https://ui-avatars.com/api/?name=User"}
              alt="Profile_Photo"
              className="w-[25px] h-[25px] rounded-full"
            />
          </span>
        </NavLink>
      </li>
      <li>
        <button
          onClick={logout ? logout : undefined}
          className="px-4 py-2 rounded-md text-lg cursor-pointer font-semibold hover:bg-rose-600"
        >
          Logout
        </button>
      </li>
    </>
  );

  // Anonymous User --> Login, Register
  const AnonymousUser = () => (
    <>
      <li>
        <NavLink
          to="/auth/login"
          className={({ isActive }) =>
            `${isActive ? "bg-blue-600" : ""} px-4 py-2 rounded-md text-lg cursor-pointer font-semibold hover:bg-blue-700`
          }
        >
          Login
        </NavLink>
      </li>
      <li>
        <NavLink
          to="/auth/register"
          className={({ isActive }) =>
            `${isActive ? "bg-blue-600" : ""} px-4 py-2 rounded-md text-lg cursor-pointer font-semibold hover:bg-blue-700`
          }
        >
          Register
        </NavLink>
      </li>
    </>
  );

  // Consider user authenticated if authUser exists and has an email
  const isAuthenticated = !!(authUser && authUser.email);

  return (
    <aside className="w-[600px] h-[70px]">
      <ul className="w-full h-[70px] flex justify-evenly items-center">
        <li>
          <NavLink
            to="/"
            className={({ isActive }) =>
              `${isActive ? "bg-blue-600" : ""} px-6 py-2 rounded-md text-lg cursor-pointer font-semibold hover:bg-blue-700`
            }
          >
            Home
          </NavLink>
        </li>
        {isAuthenticated ? <AuthenticatedUser /> : <AnonymousUser />}
      </ul>
    </aside>
  );
};

export default Menu;