import React from 'react'
// Adjust the path as necessary
import logo from '../assets/EMS-Logo.png.jpeg'
const Logo = () => {
  return (
    <aside className='w-[150px] h-[70px] flex items-center'>
      <img src={logo} alt="EMS-LOGO" 
      className='w-[140px] h-[65px]'/>
    </aside>
  )
}

export default Logo