// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDeBDnBW0Jbjm56TsfmsGafpv5JCYroLe4",
  authDomain: "ems-project-515b0.firebaseapp.com",
  projectId: "ems-project-515b0",
  storageBucket: "ems-project-515b0.firebasestorage.app",
  messagingSenderId: "718095089888",
  appId: "1:718095089888:web:4cf3567264837ebe621085"
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);

export let __AUTH = getAuth(firebaseApp);